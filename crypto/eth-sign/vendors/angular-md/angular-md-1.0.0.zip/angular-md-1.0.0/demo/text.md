## Example 2
You can load a markdown file via `ng-include` as follows:

```html
&lt;md ng-include="'text.md'">&lt;/md>
```
